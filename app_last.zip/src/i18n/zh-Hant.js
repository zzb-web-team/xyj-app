// 繁体中文
export default {
    tip: {
    }
};