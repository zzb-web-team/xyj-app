// 英文
export default {
    tip: {
    }
};