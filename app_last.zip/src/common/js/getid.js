var pid = ''


export default {
    pid
}